public class Menu {

    //IMPRIME MENU INICIAL
    public static void imprimeMenu(){
        System.out.println("Menu:");
        System.out.println("====================");
        System.out.println("1-Gerenciar CURSOS: ");
        System.out.println("2-Gerenciar DISCIPLINAS: ");
        System.out.println("3-Gerenciar ALUNOS: ");
        System.out.println("4-SAIR. ");
        System.out.println("====================");
    }

    //IMPRIME MENU PARA GERENCIAR ALUNOS
    public static void imprimeSubMenuAluno(){
        System.out.println("ALUNOS: ");
        System.out.println("====================");
        System.out.println("1-Cadastrar ALUNO: ");
        System.out.println("2-Consultar ALUNO: ");
        System.out.println("3-Remover ALUNO: ");
        System.out.println("4-Atualizar ALUNO: ");
        System.out.println("5-Voltar ao MENU INICIAL. ");
        System.out.println("====================");
    }

    //IMPRIME MENU PARA GERENCIAR DISCIPLINAS
    public static void imprimeSubMenuDisciplina(){
        System.out.println("DISCIPLINAS: ");
        System.out.println("====================");
        System.out.println("1-Cadastrar DISCIPLINA: ");
        System.out.println("2-Consultar DISCIPLINA: ");
        System.out.println("3-Remover DISCIPLINA: ");
        System.out.println("4-Atualizar DISCIPLINA: ");
        System.out.println("5-Voltar ao MENU INICIAL. ");
        System.out.println("====================");
    }

    //IMPRIME MENU PARA GERENCIAR CURSOS
    public static void imprimeSubMenuCurso(){
        System.out.println("CURSOS: ");
        System.out.println("====================");
        System.out.println("1-Cadastrar CURSO: ");
        System.out.println("2-Consultar CURSO: ");
        System.out.println("3-Remover CURSO: ");
        System.out.println("4-Atualizar CURSO: ");
        System.out.println("5-Cadastrar DISCIPLINAS");
        System.out.println("6-Voltar ao MENU INICIAL. ");
        System.out.println("====================");
    }

    //GERENCIA MENU INICIAL
    public static void GerenciaMenu(){

        int opcao;
        do{
            imprimeMenu();
            System.out.println("Informe uma opção do Menu: ");
            opcao = Utils.inputInt();
            SelecionaMenu(opcao);
        }while (opcao != 4);
    }

    //GERENCIA MENU DE ALUNOS
    public static void GerenciaSubMenuAluno(){

        int opcao;
        imprimeSubMenuAluno();
        System.out.println("Informe uma opção do Menu: ");
        opcao = Utils.inputInt();
        SelecionaMenuAluno(opcao);
    }

    //GERENCIA MENU DE DISCIPLINA
    public static void GerenciaSubMenuDisciplina(){

        int opcao;
        imprimeSubMenuDisciplina();
        System.out.println("Informe uma opção do Menu: ");
        opcao = Utils.inputInt();
        SelecionaMenuDisciplina(opcao);
    }

    //GERENCIA MENU DE CURSOS
    public static void GerenciaSubMenuCursos(){

        int opcao;
        imprimeSubMenuCurso();
        System.out.println("Informe uma opção do Menu: ");
        opcao = Utils.inputInt();
        SelecionaMenuCurso(opcao);
    }

    //SELECIONA OPÇÃO NO MENU INICIAL
    static void SelecionaMenu(int opcao){
    switch (opcao){
        case 1:
            GerenciaSubMenuCursos();
            break;
            case 2:
                GerenciaSubMenuDisciplina();
                break;
                case 3:
                    GerenciaSubMenuAluno();
                    break;
        }
    }

    //SELECIONA OPÇÃO NO MENU DE ALUNOS
    public static void SelecionaMenuAluno(int opcao){
        switch (opcao){
            case 1:
                AlunoDAO.Cadastrar();
                break;
                case 2:
                    AlunoDAO.Ler();
                    break;
                    case 3:
                        AlunoDAO.Remover();
                        break;
                        case 4:
                            AlunoDAO.Atualizar();
                            break;
                            case 5:
                                GerenciaMenu();
        }
    }

    //SELECIONA OPÇÃO NO MENU DE DISCIPLINAS
    public static void SelecionaMenuDisciplina(int opcao){
        switch (opcao){
            case 1:
                DisciplinaDAO.Cadastrar();
                break;
            case 2:
                DisciplinaDAO.Ler();
                break;
                case 3:
                    DisciplinaDAO.Remover();
                    break;
                    case 4:
                        DisciplinaDAO.Atualizar();
                        break;
                        case 5:
                            GerenciaMenu();
        }
    }

    //SELECIONA OPÇÃO NO MENU DE CURSOS
    public static void SelecionaMenuCurso(int opcao){
        switch (opcao){
            case 1:
                CursoDAO.Cadastrar();
                break;
            case 2:
                CursoDAO.Ler();
                break;
            case 3:
                CursoDAO.Remover();
                break;
                case 4:
                    CursoDAO.Atualizar();
                    break;
                    case 5:
                        CursoDAO.cadastrarDisciplinas();
                        break;
                        case 6:
                            GerenciaMenu();
        }
    }
}
