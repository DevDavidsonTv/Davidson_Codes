import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CursoDAO {
    private static int id = 0;
    public static List<Curso> cursoList = new ArrayList<Curso>();
    public static List<Disciplina> disciplinaList = new ArrayList<Disciplina>();

    //CADASTRAR CURSO
    public static void Cadastrar(){

        int idCurso = ++id;

        System.out.println("Informe o nome do Curso: ");
        String nome = Utils.inputString();

        System.out.println("Informe o turno em que o curso será ofertado: ");
        String turno = Utils.inputString();

        Curso curso = new Curso(idCurso, nome, turno);
        cursoList.add(curso);

        System.out.println("Curso cadastrado com sucesso!");

    }

    //VER ALUNOS CADASTRADOS
    public static void Ler(){
        if(!cursoList.isEmpty()) {
            for (Curso curso : cursoList) {
                System.out.println(curso.toString());
                System.out.println("======================");
            }
            for (Disciplina disciplina : disciplinaList) {
                System.out.println(disciplina.toString());
                System.out.println("======================");
            }
        }
        else
        {
            System.out.println("Nenhum curso encontrado, crie cursos voltando no MENU DE CURSOS!");
            System.out.println("Aperte ENTER para VOLTAR!");
        }
        Menu.GerenciaSubMenuCursos();
    }

    //REMOVER CURSOS
    public static void Remover(){
        if(!cursoList.isEmpty()) {
            System.out.println("Escolha o curso que deseja remover: ");

            for (Curso curso : cursoList) {
                System.out.println(curso.cursoMenu());
            }

            System.out.println("Digite o id do curso que deseja remover: ");
            int idCurso = Utils.inputInt();

            Optional<Curso> curso = cursoList.stream().filter(c -> c.getId() == idCurso).findFirst();

            if (curso.isEmpty()) {
                System.out.println("Curso não encontrado. ");
            } else {
                cursoList.remove(curso.get());
                System.out.println("Curso removido com sucesso!");
            }
        }
        else
        {
            System.out.println("Nenhum curso encontrado, crie cursos voltando no MENU DE CURSOS!");
            System.out.println("Aperte ENTER para VOLTAR!");
        }
        Menu.GerenciaSubMenuCursos();
    }

    //ATUALIZAR DADOS DE CURSOS
    public static void Atualizar(){
        if(!cursoList.isEmpty()) {
            System.out.println("Escolha o curso que deseja atualizar: ");

            for (Curso curso : cursoList) {
                System.out.println(curso.cursoMenu());
            }

            System.out.println("Digite o id do Curso que deseja atualizar: ");
            int idCurso = Utils.inputInt();

            Optional<Curso> curso = cursoList.stream().filter(c -> c.getId() == idCurso).findFirst();

            if (curso.isEmpty()) {
                System.out.println("Curso não enconctrado. ");
            } else {
                System.out.println("Informe o nome do curso: ");
                String nome = Utils.inputString();
                if (!nome.isEmpty()) {
                    curso.get().setNome(nome);
                }

                System.out.println("Informe o turno do curso: ");
                String turno = Utils.inputString();
                if (!turno.isEmpty()) {
                    curso.get().setTurno(turno);
                }

                System.out.println("Informe o nome: ");
                nome = Utils.inputString();

                System.out.println("Informe o turno: ");
                turno = Utils.inputString();

                curso.get().atualizaAll(nome, turno);
            }
        }
        else
        {
            System.out.println("Nenhum curso encontrado, crie cursos voltando no MENU DE CURSOS!");
            System.out.println("Aperte ENTER para VOLTAR!");
        }
        Menu.GerenciaSubMenuCursos();
    }

    //CADASTRAR DISCIPLINAS NO CURSO
    public static void cadastrarDisciplinas(){
        if(CursoDAO.disciplinaList.size() == 5 ) {
            System.out.println("Limite de disciplinas atingido. ");
        }
        else {
            DisciplinaDAO.listarDisciplinas();
            System.out.println("Digite o id do Disciplina que deseja adicionar: ");
            int idDisciplina = Utils.inputInt();
            Optional<Disciplina> disciplina = DisciplinaDAO.GetDisciplina(idDisciplina);
            CursoDAO.disciplinaList.add(disciplina.get());

            cadastrarDisciplinas();
        }

    }
}
