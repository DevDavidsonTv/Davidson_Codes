import java.util.ArrayList;
import java.util.List;

public class Curso{
    int id;
    private String nome;
    private String turno;


    public Curso(int id, String nome, String turno) {
        this.id = id;
        this.nome = nome;
        this.turno = turno;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    //METÓDO PARA A LISTAGEM DE CURSOS JA CADASTRADOS
    public String toString(){
        return "Curso{" +
                "id=" + id +
                ", nome ='" + nome + '\'' +
                ", turno ='" + turno + '\'' +
                '}';
    }

    //MÉTODO PARA APRESENTAR OPÇÕES PARA ATUALIZAR OU REMOVER
    public String cursoMenu(){
        return id + "-" + nome;
    }

    //MÉTODO PARA ATUALIZAR INFORMAÇÕES
    public void atualizaAll(String nome, String turno) {
        this.nome = nome;
        this.turno = turno;
    }
}
