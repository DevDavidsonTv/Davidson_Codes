import java.time.LocalDate;
import java.util.Scanner;

public class Utils {

    public static int inputInt(){
    Scanner scan = new Scanner(System.in);
        return scan.nextInt();
    }

    public static String inputString(){
        Scanner scan = new Scanner(System.in);
        return scan.next();
    }

    public static void LerData(){
        Scanner scan = new Scanner(System.in);
        String data = scan.nextLine();
        LocalDate dataN = LocalDate.parse(data);
    }

}
