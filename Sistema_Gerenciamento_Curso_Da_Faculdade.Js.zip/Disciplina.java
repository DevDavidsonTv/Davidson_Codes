import java.util.ArrayList;
import java.util.List;

public class Disciplina {

    private int id;
    private String nome;
    private String cargaHoraria;
    private double nota;
    private final List<Curso> cursos;

    public Disciplina(int id, String nome, String cargaHoraria){
        this.id = id;
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
        this.cursos = new ArrayList<>();
        this.nota = getNota();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(String cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    //METÓDO PARA A LISTAGEM DE DISCIPLINAS JA CADASTRADOS
    public String toString(){
        return "Disciplina{" +
                "id=" + id +
                ", nome ='" + nome + '\'' +
                ", carga horaria ='" + cargaHoraria + '\'' +
                '}';
    }

    //MÉTODO PARA APRESENTAR OPÇÕES PARA ATUALIZAR OU REMOVER
    public String disciplinaMenu(){
        return id + "-" + nome;
    }

    //MÉTODO PARA ATUALIZAR INFORMAÇÕES
    public void atualizaAll(String nome, String cargaHoraria) {
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
    }
}
