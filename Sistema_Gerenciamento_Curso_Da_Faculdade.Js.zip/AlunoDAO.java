import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class AlunoDAO {
    private static int id = 0;
    public static List<Aluno> alunoList = new ArrayList<Aluno>();

    //CADASTRAR ALUNO
    public static void Cadastrar(){
        if (!CursoDAO.cursoList.isEmpty()) {
            int idAluno = ++id;

            System.out.println("Informe o nome do Aluno: ");
            String nome = Utils.inputString();


            System.out.println("Informe o CPF do Aluno: (Formato: 11111111111)");
            String cpf;

            do {

                cpf = Utils.inputString();
                if (cpf.length() != 11) {
                    System.out.println("CPF inválido, deve ter 11 digitos, verifique.");
                    System.out.println("Digite o CPF do Aluno: ");
                }

            }while(cpf.length() != 11);

                System.out.println("Informe a idade do Aluno: ");
                int idade;

                do {

                    idade = Utils.inputInt();
                    if (idade < 18) {
                        System.out.println("O aluno tem que ser maior de idade. ");
                        System.out.println("Informe a idade do Aluno: ");
                    }
                }while(idade < 18);
                    for (Curso curso : CursoDAO.cursoList) {
                        System.out.println(curso.cursoMenu());
                    }

                    System.out.println("Informe o nome do curso do Aluno: ");
                    String nomeCurso = Utils.inputString();

                    Optional<Curso> curso = CursoDAO.cursoList.stream().filter(c -> Objects.equals(c.getNome(), nomeCurso)).findFirst();

                    if (CursoDAO.cursoList.isEmpty()) {
                        System.out.println("Ops, aconteceu algo de errado. Verifique se você digitou o nome do curso certo");
                    } else {
                        Aluno aluno = new Aluno(idAluno, nome, cpf, idade);
                        aluno.setCurso(curso.get());
                        alunoList.add(aluno);

                        System.out.println("Aluno cadastrado com sucesso!");
                    }
        }
        else
        {
            System.out.println("Crie CURSOS para CRIAR ALUNOS!");
            System.out.println("Aperte ENTER para VOLTAR!");
        }
        Menu.GerenciaSubMenuAluno();
    }

    //VER ALUNOS CADASTRADOS
    public static void Ler(){
        if(!alunoList.isEmpty()) {
            for (Aluno aluno : alunoList) {
                System.out.println(aluno.toString());
                System.out.println("====================");
            }
        }
        else
        {
            System.out.println("Nenhum aluno encontrado, crie ALUNOS! ");
            System.out.println("Aperte ENTER para VOLTAR!");
        }
        Menu.GerenciaSubMenuAluno();
    }

    //REMOVER ALUNOS
    public static void Remover(){
        if(alunoList.isEmpty()) {
            System.out.println("Escolha o aluno que deseja remover");

            for (Aluno aluno : alunoList) {
                System.out.println(aluno.alunoMenu());
            }

            System.out.println("Digite o id do Aluno que deseja remover: ");
            int idAluno = Utils.inputInt();

            Optional<Aluno> aluno = alunoList.stream().filter(a -> a.getId() == idAluno).findFirst();

            if (aluno.isEmpty()) {
                System.out.println("Aluno não encontrado. ");
            } else {
                alunoList.remove(aluno.get());
                System.out.println("Aluno removido com sucesso!");
            }
        }
        else
        {
            System.out.println("Nenhum aluno encontrado, crie ALUNOS! ");
            System.out.println("Aperte ENTER para VOLTAR!");
        }
        Menu.GerenciaSubMenuAluno();
    }

    //ATUALIZAR DADOS DE ALUNOS
    public static void Atualizar(){
        if(!alunoList.isEmpty()) {

            System.out.println("Lista de Alunos: ");
            for (Aluno aluno : alunoList) {
                System.out.println(aluno.alunoMenu());
            }
            System.out.println("Digite o id do Aluno que deseja atualizar: ");
            int idAluno = Utils.inputInt();

            Optional<Aluno> aluno = alunoList.stream().filter(a -> a.getId() == idAluno).findFirst();

            if (aluno.isEmpty()) {
                System.out.println("Aluno não encontrado. ");
            }else {
                System.out.println("\nOpções de Atualização:");
                System.out.println("1. Nome");
                System.out.println("2. CPF");
                System.out.println("3. Idade");
                System.out.println("4. Curso");
                System.out.println("5. Voltar para Menu");

                System.out.println("Digite a opção desejada: ");
                int opcao = Utils.inputInt();


                switch (opcao) {
                    case 1:
                        System.out.println("Informe o nome do Aluno: ");
                        String nome = Utils.inputString();
                        if (!nome.isEmpty()) {
                            aluno.get().setNome(nome);
                        }
                        System.out.println("Nome atualizado com sucesso!");
                        break;

                    case 2:
                        System.out.println("Informe o CPF do Aluno: ");
                        String cpf = Utils.inputString();
                        if (!cpf.isEmpty()) {
                        aluno.get().setCpf(cpf);
                        }
                        System.out.println("CPF atualizado com sucesso!");
                        break;

                    case 3:
                        System.out.println("Informe a idade do Aluno: ");
                        int idade = Utils.inputInt();
                        if (idade > 0) {
                        aluno.get().setIdade(idade);
                        }
                        System.out.println("Idade atualizada com sucesso!");
                        break;

                    case 4:
                        System.out.println("Cursos disponíveis: ");
                        for (Curso curso : CursoDAO.cursoList) {
                        System.out.println(curso.cursoMenu());
                        }

                        System.out.println("Informe o nome do novo curso: ");
                        String nomeCurso = Utils.inputString();

                        Optional<Curso> novoCurso = CursoDAO.cursoList.stream().filter(c -> Objects.equals(c.getNome(), nomeCurso)).findFirst();

                        if (novoCurso.isPresent()) {
                            aluno.get().setCurso(novoCurso.get()); // Update student's course
                            System.out.println("Curso atualizado com sucesso!");
                        } else {
                            System.out.println("Curso não encontrado.");
                        }
                        break;

                }
            }
        }
        else
        {
            System.out.println("Nenhum aluno encontrado, crie ALUNOS! ");
            System.out.println("Aperte ENTER para VOLTAR!");
        }
        Menu.GerenciaSubMenuAluno();
    }
}
