import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DisciplinaDAO {
    private static int id = 0;
    public static List<Disciplina> disciplinaList = new ArrayList<Disciplina>();

    //CADASTRAR DISCIPLINA
    public static void Cadastrar() {
        if (!CursoDAO.cursoList.isEmpty()) {
            int idDisciplina = ++id;

            System.out.println("Informe o nome da Disciplina: ");
            String nome = Utils.inputString();

            System.out.println("Informe a Carga Horaria da Disciplina: ");
            String cargaHoraria = Utils.inputString();

            Disciplina disciplina = new Disciplina(idDisciplina, nome, cargaHoraria);
            disciplinaList.add(disciplina);

            System.out.println("Disciplina cadastrada com sucesso!");
        }
        else
        {
            System.out.println("Crie CURSOS para criar disciplinas! ");
            System.out.println("Aperte ENTER para VOLTAR!");
        }
        Menu.GerenciaSubMenuDisciplina();
    }

    //VER DISCIPLINAS CADASTRADOS
    public static void Ler(){
        if(!disciplinaList.isEmpty()) {
            for (Disciplina disciplina : disciplinaList) {
                System.out.println(disciplina.toString());
                System.out.println("====================");
            }
        }
        else
        {
            System.out.println("Nenhuma disciplina encontrada, crie disciplinas voltando no MENU DE DISCIPLINAS!");
            System.out.println("Aperte ENTER para VOLTAR!");
        }
        Menu.GerenciaSubMenuDisciplina();
    }

    //REMOVER DISCIPLINAS
    public static void Remover(){
        if(!disciplinaList.isEmpty()) {
            System.out.println("Escolha a disciplina que deseja remover");

            for (Disciplina disciplina : disciplinaList) {
                System.out.println(disciplina.disciplinaMenu());
            }

            System.out.println("Digite o id da Disciplina que deseja remover: ");
            int idDisciplina = Utils.inputInt();

            Optional<Disciplina> disciplina = disciplinaList.stream().filter(d -> d.getId() == idDisciplina).findFirst();

            if (disciplina.isEmpty()) {
                System.out.println("Disciplina não encontrada. ");
            } else {
                disciplinaList.remove(disciplina.get());
                System.out.println("Disciplina removida com sucesso!");
            }
        }
        else
        {
            System.out.println("Nenhuma disciplina encontrada, crie disciplinas voltando no MENU DE DISCIPLINAS!");
            System.out.println("Aperte ENTER para VOLTAR!");
        }
        Menu.GerenciaSubMenuDisciplina();
    }

    //ATUALIZAR DISCIPLINAS
    public static void Atualizar(){
        if(!disciplinaList.isEmpty()) {
            System.out.println("Escolha a Disciplina que deseja atualizar");

            for (Disciplina disciplina : disciplinaList) {
                System.out.println(disciplina.disciplinaMenu());
            }

            System.out.println("Digite o id da Disciplina que deseja atualizar: ");
            int idDisciplina = Utils.inputInt();

            Optional<Disciplina> disciplina = disciplinaList.stream().filter(d -> d.getId() == idDisciplina).findFirst();

            if (disciplina.isEmpty()) {
                System.out.println("Disciplina não encontrada. ");
            } else {
                System.out.println("Informe o nome da disciplina: ");
                String nome = Utils.inputString();
                if (!nome.isEmpty()) {
                    disciplina.get().setNome(nome);
                }

                System.out.println("Informe a carga horaria do curso: ");
                String cargaHoraria = Utils.inputString();
                if (!cargaHoraria.isEmpty()) {
                    disciplina.get().setCargaHoraria(cargaHoraria);
                }

                System.out.println("Informe o nome: ");
                nome = Utils.inputString();

                System.out.println("Informe a carga horaria: ");
                cargaHoraria = Utils.inputString();

                disciplina.get().atualizaAll(nome, cargaHoraria);
            }
        }
        else
        {
            System.out.println("Nenhuma disciplina encontrada, crie disciplinas voltando no MENU DE DISCIPLINAS!");
            System.out.println("Aperte ENTER para VOLTAR!");
        }
        Menu.GerenciaSubMenuDisciplina();
    }

    public static void listarDisciplinas(){
        for (Disciplina disciplina : disciplinaList){
            System.out.println(disciplina.getId() + "-" + disciplina.getNome());
        }
    }

    public static Optional<Disciplina> GetDisciplina (int id){
        Optional<Disciplina> disciplina = disciplinaList.stream().filter(c -> c.getId() == id).findFirst();

        if (disciplina.isEmpty()){
            System.out.println("Cliente não encontrado. ");
        }
        else
        {
            return disciplina;
        }
        return null;
    }
}

