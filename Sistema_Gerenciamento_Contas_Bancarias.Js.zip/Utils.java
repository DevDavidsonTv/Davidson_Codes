import java.time.LocalDate;
import java.util.Scanner;

public class Utils {

    public static double inputDouble(){
        Scanner sc = new Scanner(System.in);
        return sc.nextDouble();
    }
    public static int inputInt() {
        Scanner scan = new Scanner(System.in);
        return scan.nextInt();
    }

    public static String inputString() {
        Scanner scan = new Scanner(System.in);
        return scan.next();
    }

    public static LocalDate LerData() {
        Scanner scan = new Scanner(System.in);
        String data = scan.nextLine();
        LocalDate dataN = LocalDate.parse(data);
        return LocalDate.parse(data);
    }

}
