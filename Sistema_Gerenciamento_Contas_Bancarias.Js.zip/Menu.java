public class Menu {

    //IMPRIME MENU INICIAL
    public static void imprimeMenu(){
        System.out.println("Menu:");
        System.out.println("====================");
        System.out.println("1-Gerenciar CLIENTES: ");
        System.out.println("2-Gerenciar CONTAS: ");
        System.out.println("3-SAIR. ");
        System.out.println("====================");
    }

    //IMPRIME MENU CLIENTES
    public static void imprimeSubMenuClientes(){
        System.out.println("Menu Clientes:");
        System.out.println("====================");
        System.out.println("1-Cadastrar CLIENTES: ");
        System.out.println("2-Consultar CLIENTES: ");
        System.out.println("3-Remover CLIENTES: ");
        System.out.println("4-Atualizar CLIENTES: . ");
        System.out.println("5-VOLTAR AO MENU INICIAL: . ");
        System.out.println("====================");
    }

    //IMPRIME MENU CONTA
    public static void imprimeSubMenuConta(){
        System.out.println("Menu Cliente e Contas:");
        System.out.println("====================");
        System.out.println("1-Criar CONTA para um CLIENTE: ");
        System.out.println("2-Sacar dinheiro de uma CONTA de um CLIENTE: ");
        System.out.println("3-Depositar dinheiro para uma CONTA de um CLIENTE: ");
        System.out.println("4-Verificar saldo de uma CONTA de um CLIENTE: ");
        System.out.println("5-Transferir dinheiro de uma CONTA de um CLIENTE para outro CLIENTE: ");
        System.out.println("5-VOLTAR AO MENU INICIAL. ");
        System.out.println("====================");
    }

    //GERENCIA MENU INICIAL
    public static void gerenciaMenu(){

        int opcao;
        do {
            imprimeMenu();
            System.out.println("Informe uma opção do MENU: ");
            opcao = Utils.inputInt();
            SelecionaMenu(opcao);


        }while (opcao != 3);
    }

    //GERENCIA MENU CLIENTES
    public static void gerenciaSubMenuCliente(){

        int opcao;
        imprimeSubMenuClientes();
        System.out.println("Informe uma opção do MENU DE CLIENTES: ");
        opcao = Utils.inputInt();
        selecionaMenuCliente(opcao);

    }

    //GERENCIA MENU CONTAS
    public static void gerenciaSubMenuConta(){

        int opcao;
        imprimeSubMenuConta();
        System.out.println("Informe uma opção do MENU DE CONTAS: ");
        opcao = Utils.inputInt();
        selecionaMenuConta(opcao);
    }

    //SELECIONA MENU INICIAL
    public static void SelecionaMenu(int opcao){
        switch (opcao){
            case 1:
                gerenciaSubMenuCliente();
                break;
            case 2:
                gerenciaSubMenuConta();
                break;
        }
    }
    
    public static void selecionaMenuCliente(int opcao){
        switch (opcao){
            case 1:
                ClienteDAO.Cadastrar();
                break;
            case 2:
                ClienteDAO.ler();
                break;
                case 3:
                    ClienteDAO.Excluir();
                    break;
                    case 4:
                        ClienteDAO.atualizar();
                        break;
                        case 5:
                            gerenciaMenu();
                            break;

        }
    }

    public static void selecionaMenuConta(int opcao){
        switch (opcao){
            case 1:
                ContaDAO.criarAcc();
                break;
            case 2:
                ContaDAO.sacarDinheiro();
                break;
                case 3:
                    ContaDAO.depositarDinheiro();
                    break;
                    case 4:
                        ContaDAO.verSaldo();
                        break;
                        case 5:
                            ContaDAO.transferencia();
                            break;
                            case 6:
                                gerenciaMenu();
                                break;
        }
    }
}
