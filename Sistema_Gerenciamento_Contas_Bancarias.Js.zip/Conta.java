public class Conta {
    private int numeroAcc;
    private double saldo;
    private Cliente cliente;

    public Conta(int numero, double saldo, Cliente cliente) {
        this.numeroAcc = numero;
        this.saldo = saldo;
        this.cliente = cliente;
    }

    public int getNumero() {
        return numeroAcc;
    }

    public void setNumero(int numero) {
        this.numeroAcc = numero;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String toString(){
        return "Conta{ " + "Numero da conta: " + numeroAcc + "\n" +
                "Saldo: " + saldo + "\n" +
                "Cliente: " + cliente + "}";
    }

    public String contaMenu(){
        return numeroAcc + " - " + cliente.getNome();
    }

    public String verificarSaldo(){
        return "Saldo do cliente " + cliente.getNome() + " - " + "Saldo: " + saldo;
    }
}
