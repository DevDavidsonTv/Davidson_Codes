import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public class ContaDAO {

    static Random rand = new Random();
    private static int numero = rand.nextInt(900000000) + 100000000;
    public static List<Conta> contaList = new ArrayList<>();

    //CRIAR CONTA CORRENTE
    public static void criarAcc(){
        double saldo = 0;
        int numeroAcc = ++numero;

        ClienteDAO.listarClientes();
        System.out.println("Digite o id do CLIENTE que receberá esta conta: ");
        int id = Utils.inputInt();
        Optional<Cliente> cliente = ClienteDAO.buscarClientesPorId(id);

        Conta conta = new Conta(numeroAcc, saldo, cliente.get());
        cliente.get().setConta(conta);

        System.out.println("Conta criada com sucesso!");
    }

    //SACAR DINHEIRO
    public static void sacarDinheiro(){
        for (Conta conta : contaList) {
            System.out.println(conta.contaMenu());
        }
        System.out.println("Digite o NÚMERO DA CONTA do CLIENTE que deseja sacar o dinheiro: ");
        int numeroAcc = Utils.inputInt();
        Optional<Conta> conta = buscarClientesPorNumero(numeroAcc);

        if(conta.isEmpty()){
            System.out.println("Conta não encontrada");
        }
        else
        {
            System.out.println("Digite o valor que deseja sacar: ");
            double valor = Utils.inputInt();

            if (conta.get().getSaldo() >= valor){
                conta.get().setSaldo(conta.get().getSaldo() - valor);
                System.out.println("Valor sacado com sucesso. ");
            }
            else
            {
                System.out.println("Saldo insuficiente, repita a operação. ");
            }
            Menu.gerenciaSubMenuConta();
        }
    }

    //DEPOSITAR DINHEIRO NA CONTA
    public static void depositarDinheiro(){
        System.out.println("Lista de contas: ");
        for (Conta conta : contaList){
            System.out.println(conta.contaMenu());
        }
        System.out.println("Digite o NÚMERO DA CONTA do CLIENTE que deseja depositar o dinheiro: ");
        int numeroAcc = Utils.inputInt();
        Optional<Conta> conta = buscarClientesPorNumero(numeroAcc);

        if(conta.isEmpty()){
            System.out.println("Conta não encontrada. Tente novamente.");
            depositarDinheiro();
        }
        else
        {
            System.out.println("Digite o valor que deseja depositar: ");
            double valor = Utils.inputInt();

            if (valor >= 0){
                conta.get().setSaldo(conta.get().getSaldo() + valor);
                System.out.println("Valor depositado com sucesso. ");
            }
            else
            {
                System.out.println("Impossível sacar 0 reais. ");
            }
        }
    }

    //VERIFICAR SALDO DE UMA CONTA
    public static void verSaldo() {

        for (Conta conta : contaList) {
            System.out.println(conta.contaMenu());
        }
        System.out.println("Digite o NÚMERO DA CONTA QUE VOCÊ DESEJA VERIFICAR O SALDO: ");
        int numero = Utils.inputInt();
        Optional<Conta> conta = buscarClientesPorNumero(numero);

        if (conta.isEmpty()){
            System.out.println("Conta não encontrada. ");
            verSaldo();
        }
        else
        {
            double valor = conta.get().getSaldo();
            System.out.println("Saldo: " + valor);
        }
    }

    //TRASFERIR DE UMA CONTA DE UM CLIENTE PARA OUTRO CLIENTE
    public static void transferencia (){

        for (Conta conta : contaList) {
            System.out.println(conta.contaMenu());
        }

        System.out.println("Digite o NÚMERO DA CONTA que irá enviar o dinheiro: ");
        int numero1 = Utils.inputInt();
        Optional<Conta> conta1 = buscarClientesPorNumero(numero1);

        System.out.println("Agora digite o NÚMERO DA CONTA que irá receber o dinheiro: ");
        int numero2 = Utils.inputInt();
        Optional<Conta> conta2 = buscarClientesPorNumero(numero2);

        System.out.println("O saldo da conta " + conta1.get().getNumero() + "é de " + conta1.get().getSaldo());
        System.out.println("Qual valor deseja enviar para " + conta2.get().getCliente() + "?");
        double valor = Utils.inputDouble();

        if(valor <= conta1.get().getSaldo()){
            conta1.get().setSaldo(conta1.get().getSaldo() - valor);
            conta2.get().setSaldo(conta2.get().getSaldo() + valor);
        }
        else
        {
            System.out.println("Digite um valor válido. ");
            transferencia();
        }
    }

    private static Optional<Conta> buscarClientesPorNumero(int numeroAcc){
        Optional<Conta> conta = contaList.stream().filter(c -> c.getNumero() == numero).findFirst();

        if (conta.isEmpty()){
            System.out.println("Cliente não encontrado. ");
        }
        else
        {
            return conta;
        }
        return null;
    }
}


