public class Cliente {
    private final int idCliente;
    public String nome;
    private String cpf;
    private String idade;
    private Conta conta;

    public Cliente(int idCliente, String nome, String cpf, String idade) {
        this.idCliente = idCliente;
        this.nome = nome;
        this.cpf = cpf;
        this.idade = idade;
        this.conta = getConta();
    }

    public int getIdCliente() {
        return idCliente;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public Conta getConta() {
        return conta;
    }

    public void setConta(Conta conta) {
        this.conta = conta;
    }

    public String toString(){
        return "Cliente{ " + "id: " + idCliente + "\n" +
                "nome: " + nome + "\n" +
                "CPF: " + cpf + "\n" +
                "Idade: " + idade + "\n" +
                "Conta: " + conta + "}";
    }

    public String clienteMenu(){
        return idCliente + " - " + nome;
    }

    public void atualizaAll(String nome, String cpf, String idade) {
        this.nome = nome;
        this.cpf = cpf;
        this.idade = idade;
    }
}

