import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public class ClienteDAO {
    public static List<Cliente> clienteList = new ArrayList<Cliente>();
    private static int id = 0;

    //CADASTRAR CLIENTES
    public static void Cadastrar(){

        int idCliente = ++id;

        System.out.println("Digite o Nome Completo do cliente: ");
        String nome = Utils.inputString();

        System.out.println("Digite o CPF do cliente: ");
        String cpf = Utils.inputString();

        System.out.println("Digita a idade do cliente: ");
        String idade = Utils.inputString();

        Cliente cliente = new Cliente(idCliente, nome, cpf, idade);
        clienteList.add(cliente);

        System.out.println("Cliente cadastrado com sucesso!");

    }

    //LISTAR CLIENTES
    public static void ler(){
        for (Cliente cliente : clienteList){
            System.out.println(cliente.toString());
            System.out.println("====================");
        }
        Menu.gerenciaSubMenuCliente();
    }

    //EXCLUIR CLIENTES
    public static void Excluir(){
        for (Cliente cliente : clienteList){
            System.out.println(cliente.clienteMenu());
        }
        System.out.println("Digite o id do cliente que você deseja remover: ");
        int id = Utils.inputInt();

        Optional<Cliente> cliente = clienteList.stream().filter(c -> c.getIdCliente() == id).findFirst();

        if(cliente.isEmpty()){
            System.out.println("Cliente não encontrado! ");
            Excluir();
        }
        else
        {
            clienteList.remove(cliente.get());
            System.out.println("Cliente removido com sucesso!");
            Menu.gerenciaSubMenuCliente();
        }
    }

    //ATUALIZAR CLIENTES
    public static void atualizar(){
        for (Cliente cliente : clienteList){
            System.out.println(cliente.clienteMenu());
        }
        System.out.println("Digite o id do cliente que você deseja atualizar: ");
        int id = Utils.inputInt();

        Optional<Cliente> cliente = clienteList.stream().filter(c -> c.getIdCliente() == id).findFirst();

        if(cliente.isEmpty()){
            System.out.println("Cliente não encontrado! ");
        }
        else
        {
            System.out.println("\nOpções de Atualização:");
            System.out.println("1. Nome");
            System.out.println("2. CPF");
            System.out.println("3. Idade");
            System.out.println("4. Conta");
            System.out.println("5. Voltar para Menu");

            System.out.println("Digite a opção desejada: ");
            int opcao = Utils.inputInt();

            switch (opcao){
                case 1:
                    System.out.println("Informe o nome do Cliente: ");
                    String nome = Utils.inputString();
                    if (!nome.isEmpty()) {
                        cliente.get().setNome(nome);
                    }
                    System.out.println("Nome atualizado com sucesso!");
                    break;

                case 2:
                    System.out.println("Informe o CPF do Cliente: ");
                    String cpf = Utils.inputString();
                    if (cpf.isEmpty()) {
                        cliente.get().setCpf(cpf);
                    }
                    System.out.println("CPF atualizado com sucesso!");
                    break;

                    case 3:
                        System.out.println("Informe a idade do Cliente: ");
                        String idade = Utils.inputString();
                        if (idade != null) {
                            cliente.get().setIdade(idade);
                        }
                        System.out.println("Idade atualizada com sucesso!");
                        break;
            }
        }
        Menu.gerenciaSubMenuCliente();
    }

    public static void listarClientes(){
        for (Cliente cliente : clienteList){
            System.out.println(cliente.getIdCliente() + "-" + cliente.getNome());
        }
    }

    public static Optional<Cliente> buscarClientesPorId(int id){
        Optional<Cliente> cliente = clienteList.stream().filter(c -> c.getIdCliente() == id).findFirst();

        if (cliente.isEmpty()){
            System.out.println("Cliente não encontrado. ");
        }
        else
        {
            return cliente;
        }
        return null;
    }

}
