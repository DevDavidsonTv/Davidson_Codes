﻿using System;

namespace CPS___Taskyou___Entrega_Final
{
    internal class Usuario
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string CPF { get; set; }
        public int Idade { get; set; }
        public string Email { get; set; }
        public string Senha { get; set; }

        public void Autenticar()
        {
            // Lógica de autenticação
            Console.WriteLine("Usuário autenticado com sucesso.");
        }

        public override string ToString()
        {
            return $"ID: {Id}, Nome: {Nome}, CPF: {CPF}, Idade: {Idade}, Email: {Email}";
        }
    }
}
