﻿public class Tarefa
{
    public int Id { get; set; }
    public int UsuarioId { get; set; }
    public int? ListaId { get; set; } // ListaId é opcional
    public string Nome { get; set; }
    public string Descricao { get; set; }
    public DateTime DataInicio { get; set; }
    public string Prioridade { get; set; }
    public string Status { get; set; }

    public override string ToString()
    {
        return $"ID: {Id}, Nome: {Nome}, Descrição: {Descricao}, Prioridade: {Prioridade}, Status: {Status}, Data de Início: {DataInicio.ToShortDateString()}";
    }
}
