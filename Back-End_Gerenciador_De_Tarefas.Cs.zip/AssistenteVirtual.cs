﻿using System;

namespace CPS___Taskyou___Entrega_Final
{
    internal class AssistenteVirtual
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        public void ProcessarTexto(string texto)
        {
            // Lógica para processar texto
            Console.WriteLine($"Assistente {Nome} processando texto: {texto}");
        }

        public void ResponderTexto()
        {
            // Lógica para responder texto
            Console.WriteLine($"Assistente {Nome} respondendo...");
        }
    }
}
