﻿using CPS___Taskyou___Entrega_Final;

public class ListaDeTarefas
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public string Descricao { get; set; }
    public List<Tarefa> Tarefas { get; set; }

    public ListaDeTarefas()
    {
        Tarefas = new List<Tarefa>();
    }

    public override string ToString()
    {
        return $"ID: {Id}, Nome: {Nome}, Descrição: {Descricao}, Quantidade de Tarefas: {Tarefas.Count}";
    }
}
