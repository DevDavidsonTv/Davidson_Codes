﻿using System;

namespace CPS___Taskyou___Entrega_Final
{
    internal class Mensagem
    {
        public int Id { get; set; }
        public string Conteudo { get; set; }
        public DateTime DataEnvio { get; set; }
        public int RemetenteId { get; set; }
        public int DestinatarioId { get; set; }
    }
}
