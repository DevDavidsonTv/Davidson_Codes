﻿using System;
using System.Collections.Generic;

namespace CPS___Taskyou___Entrega_Final
{
    internal class ContatoDAO
    {
        private List<Contato> contatos;

        public ContatoDAO()
        {
            contatos = new List<Contato>();
        }

        public void AdicionarContato(Contato contato)
        {
            contatos.Add(contato);
            Console.WriteLine($"Contato '{contato.Nome}' adicionado.");
        }

        public void ExcluirContato(Contato contato)
        {
            contatos.Remove(contato);
            Console.WriteLine($"Contato '{contato.Nome}' removido.");
        }
    }
}
