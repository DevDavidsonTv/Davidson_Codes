﻿using System;
using System.Collections.Generic;

namespace CPS___Taskyou___Entrega_Final
{
    class Program
    {
        static UsuarioDAO usuarioDAO = new UsuarioDAO();
        static TarefaDAO tarefaDAO = new TarefaDAO();

        static void Main(string[] args)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("===== TaskYou =====");
            Console.ResetColor();
            Console.WriteLine("Bem-vindo ao TaskYou!");
            Console.WriteLine("Pressione qualquer tecla para iniciar...");
            Console.ReadKey();
            Console.Clear();

            while (true)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("===== Menu Principal =====");
                Console.ResetColor();
                Console.WriteLine("1. Cadastro de Usuário");
                Console.WriteLine("2. Login de Usuário");
                Console.WriteLine("3. Sair");

                Console.Write("Selecione uma opção: ");
                string opcao = Console.ReadLine();

                switch (opcao)
                {
                    case "1":
                        MenuCadastroUsuario();
                        break;
                    case "2":
                        Usuario usuarioLogado = MenuLoginUsuario();
                        if (usuarioLogado != null)
                        {
                            MenuUsuarioLogado(usuarioLogado);
                        }
                        break;
                    case "3":
                        return;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Opção inválida. Pressione qualquer tecla para tentar novamente.");
                        Console.ResetColor();
                        Console.ReadKey();
                        break;
                }
            }
        }

        static void MenuCadastroUsuario()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("===== Cadastro de Usuário =====");
            Console.ResetColor();

            Usuario usuario = new Usuario();

            Console.Write("Nome: ");
            usuario.Nome = Console.ReadLine();

            Console.Write("CPF: ");
            usuario.CPF = Console.ReadLine();

            Console.Write("Idade: ");
            usuario.Idade = int.Parse(Console.ReadLine());

            Console.Write("Email: ");
            usuario.Email = Console.ReadLine();

            Console.Write("Senha: ");
            usuario.Senha = Console.ReadLine();

            usuarioDAO.AdicionarUsuario(usuario);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Usuário cadastrado com sucesso!");
            Console.ResetColor();

            Console.WriteLine("Pressione qualquer tecla para continuar...");
            Console.ReadKey();
            Console.Clear();
        }

        static Usuario MenuLoginUsuario()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("===== Login =====");
            Console.ResetColor();

            if (usuarioDAO.ObterTodosUsuarios().Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Nenhum usuário cadastrado. Por favor, cadastre um usuário primeiro.");
                Console.ResetColor();
                Console.WriteLine("Pressione qualquer tecla para continuar...");
                Console.ReadKey();
                return null;
            }

            Usuario usuarioLogado = null;
            while (usuarioLogado == null)
            {
                Console.Write("ID do Usuário: ");
                int usuarioId = int.Parse(Console.ReadLine());
                usuarioLogado = usuarioDAO.ObterUsuarioPorId(usuarioId);

                if (usuarioLogado == null)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Usuário não encontrado. Pressione qualquer tecla para tentar novamente.");
                    Console.ResetColor();
                    Console.ReadKey();
                }
            }

            return usuarioLogado;
        }

        static void MenuUsuarioLogado(Usuario usuarioLogado)
        {
            while (true)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine($"===== Bem-vindo, {usuarioLogado.Nome} =====");
                Console.ResetColor();
                Console.WriteLine("1. Criação de Tarefa");
                Console.WriteLine("2. Listar e Atualizar Tarefas");
                Console.WriteLine("3. Gerenciar Listas de Tarefas");
                Console.WriteLine("4. Sair");

                Console.Write("Selecione uma opção: ");
                string opcao = Console.ReadLine();

                switch (opcao)
                {
                    case "1":
                        MenuCriacaoTarefa(usuarioLogado.Id);
                        break;
                    case "2":
                        MenuListarTarefas(usuarioLogado.Id);
                        break;
                    case "3":
                        MenuGerenciarListas(usuarioLogado.Id);
                        break;
                    case "4":
                        return;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Opção inválida. Pressione qualquer tecla para tentar novamente.");
                        Console.ResetColor();
                        Console.ReadKey();
                        break;
                }
            }
        }

        static void MenuCriacaoTarefa(int usuarioId)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("===== Criação de Tarefa =====");
            Console.ResetColor();

            Tarefa tarefa = new Tarefa();

            tarefa.UsuarioId = usuarioId;

            Console.Write("Nome: ");
            tarefa.Nome = Console.ReadLine();

            Console.Write("Descrição: ");
            tarefa.Descricao = Console.ReadLine();

            Console.Write("Data de Início (dd/MM/yyyy): ");
            tarefa.DataInicio = DateTime.Parse(Console.ReadLine());

            Console.Write("Prioridade (Baixa, Média, Alta): ");
            tarefa.Prioridade = Console.ReadLine();

            tarefa.Status = "A fazer";

            Console.Write("ID da Lista de Tarefas (ou pressione Enter para pular): ");
            string listaIdInput = Console.ReadLine();
            if (!string.IsNullOrEmpty(listaIdInput))
            {
                tarefa.ListaId = int.Parse(listaIdInput);
            }

            tarefaDAO.CriarTarefa(tarefa);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Tarefa criada com sucesso!");
            Console.ResetColor();

            Console.WriteLine("Pressione qualquer tecla para continuar...");
            Console.ReadKey();
            Console.Clear();
        }

        static void MenuListarTarefas(int usuarioId)
        {
            while (true)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("===== Listar e Atualizar Tarefas =====");
                Console.ResetColor();

                Usuario usuario = usuarioDAO.ObterUsuarioPorId(usuarioId);

                if (usuario == null)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Usuário não encontrado. Pressione qualquer tecla para continuar...");
                    Console.ResetColor();
                    Console.ReadKey();
                    return;
                }

                List<Tarefa> tarefas = tarefaDAO.ObterTarefasPorUsuarioId(usuarioId);

                if (tarefas.Count == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Nenhuma tarefa encontrada para este usuário.");
                    Console.ResetColor();
                }
                else
                {
                    Console.WriteLine($"Tarefas do usuário {usuario.Nome}:");
                    foreach (var tarefa in tarefas)
                    {
                        Console.WriteLine(tarefa);
                    }

                    Console.WriteLine("0. Voltar");
                    Console.Write("Selecione o ID da tarefa para atualizar o status ou 0 para voltar: ");
                    int tarefaId;
                    if (!int.TryParse(Console.ReadLine(), out tarefaId) || tarefaId == 0)
                    {
                        return;
                    }

                    Tarefa tarefaSelecionada = tarefas.Find(t => t.Id == tarefaId);

                    if (tarefaSelecionada != null)
                    {
                        Console.WriteLine($"Tarefa selecionada: {tarefaSelecionada.Nome}");
                        Console.WriteLine("1. A fazer");
                        Console.WriteLine("2. Em andamento");
                        Console.WriteLine("3. Concluída");

                        Console.Write("Selecione o novo status: ");
                        string novoStatus = Console.ReadLine();
                        switch (novoStatus)
                        {
                            case "1":
                                tarefaSelecionada.Status = "A fazer";
                                break;
                            case "2":
                                tarefaSelecionada.Status = "Em andamento";
                                break;
                            case "3":
                                tarefaSelecionada.Status = "Concluída";
                                break;
                            default:
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Status inválido.");
                                Console.ResetColor();
                                break;
                        }

                        tarefaDAO.AtualizarTarefa(tarefaSelecionada);
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Status da tarefa atualizado com sucesso.");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Tarefa não encontrada.");
                        Console.ResetColor();
                    }
                }

                Console.WriteLine("Pressione qualquer tecla para continuar...");
                Console.ReadKey();
            }
        }

        static void MenuGerenciarListas(int usuarioId)
        {
            while (true)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("===== Gerenciar Listas de Tarefas =====");
                Console.ResetColor();
                Console.WriteLine("1. Criar Lista de Tarefas");
                Console.WriteLine("2. Listar Listas de Tarefas");
                Console.WriteLine("3. Excluir Lista de Tarefas");
                Console.WriteLine("4. Voltar");

                Console.Write("Selecione uma opção: ");
                string opcao = Console.ReadLine();

                switch (opcao)
                {
                    case "1":
                        MenuCriacaoListaDeTarefas();
                        break;
                    case "2":
                        MenuListarListasDeTarefas();
                        break;
                    case "3":
                        MenuExcluirListaDeTarefas();
                        break;
                    case "4":
                        return;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Opção inválida. Pressione qualquer tecla para tentar novamente.");
                        Console.ResetColor();
                        Console.ReadKey();
                        break;
                }
            }
        }

        static void MenuCriacaoListaDeTarefas()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("===== Criação de Lista de Tarefas =====");
            Console.ResetColor();

            ListaDeTarefas lista = new ListaDeTarefas();

            Console.Write("Nome da Lista: ");
            lista.Nome = Console.ReadLine();

            Console.Write("Descrição da Lista: ");
            lista.Descricao = Console.ReadLine();

            tarefaDAO.CriarListaDeTarefas(lista);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Lista de tarefas criada com sucesso!");
            Console.ResetColor();

            Console.WriteLine("Pressione qualquer tecla para continuar...");
            Console.ReadKey();
            Console.Clear();
        }

        static void MenuListarListasDeTarefas()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("===== Listar Listas de Tarefas =====");
            Console.ResetColor();

            List<ListaDeTarefas> listas = tarefaDAO.ObterListasDeTarefas();

            if (listas.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Nenhuma lista de tarefas encontrada.");
                Console.ResetColor();
            }
            else
            {
                foreach (var lista in listas)
                {
                    Console.WriteLine(lista);
                }
            }

            Console.WriteLine("Pressione qualquer tecla para continuar...");
            Console.ReadKey();
        }

        static void MenuExcluirListaDeTarefas()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("===== Excluir Lista de Tarefas =====");
            Console.ResetColor();

            List<ListaDeTarefas> listas = tarefaDAO.ObterListasDeTarefas();

            if (listas.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Nenhuma lista de tarefas encontrada.");
                Console.ResetColor();
            }
            else
            {
                foreach (var lista in listas)
                {
                    Console.WriteLine(lista);
                }

                Console.Write("Digite o ID da lista a ser excluída: ");
                int listaId = int.Parse(Console.ReadLine());

                tarefaDAO.ExcluirListaDeTarefas(listaId);

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Lista de tarefas excluída com sucesso!");
                Console.ResetColor();
            }

            Console.WriteLine("Pressione qualquer tecla para continuar...");
            Console.ReadKey();
        }
    }
}