﻿using System;
using System.Collections.Generic;

namespace CPS___Taskyou___Entrega_Final
{
    internal class TarefaDAO
    {
        private List<Tarefa> tarefas;
        private List<ListaDeTarefas> listasDeTarefas;

        public TarefaDAO()
        {
            tarefas = new List<Tarefa>();
            listasDeTarefas = new List<ListaDeTarefas>();
        }

        // Métodos para gerenciar tarefas
        public void CriarTarefa(Tarefa tarefa)
        {
            tarefa.Id = tarefas.Count + 1;
            tarefas.Add(tarefa);
            Console.WriteLine($"Tarefa '{tarefa.Nome}' criada.");

            if (tarefa.ListaId.HasValue)
            {
                var lista = ObterListaDeTarefasPorId(tarefa.ListaId.Value);
                lista?.Tarefas.Add(tarefa);
            }
        }

        public List<Tarefa> ObterTarefasPorUsuarioId(int usuarioId)
        {
            return tarefas.FindAll(t => t.UsuarioId == usuarioId);
        }

        public Tarefa ObterTarefaPorId(int id)
        {
            return tarefas.Find(t => t.Id == id);
        }

        public void AtualizarTarefa(Tarefa tarefa)
        {
            var tarefaExistente = ObterTarefaPorId(tarefa.Id);
            if (tarefaExistente != null)
            {
                tarefaExistente.Nome = tarefa.Nome;
                tarefaExistente.Descricao = tarefa.Descricao;
                tarefaExistente.Prioridade = tarefa.Prioridade;
                tarefaExistente.Status = tarefa.Status;
            }
        }

        public void ExcluirTarefa(int id)
        {
            var tarefa = ObterTarefaPorId(id);
            if (tarefa != null)
            {
                tarefas.Remove(tarefa);

                if (tarefa.ListaId.HasValue)
                {
                    var lista = ObterListaDeTarefasPorId(tarefa.ListaId.Value);
                    lista?.Tarefas.Remove(tarefa);
                }
            }
        }

        // Métodos para gerenciar listas de tarefas
        public void CriarListaDeTarefas(ListaDeTarefas lista)
        {
            lista.Id = listasDeTarefas.Count + 1; // Simula a criação de um ID único
            listasDeTarefas.Add(lista);
            Console.WriteLine($"Lista de tarefas '{lista.Nome}' criada.");
        }

        public List<ListaDeTarefas> ObterListasDeTarefas()
        {
            return listasDeTarefas;
        }

        public ListaDeTarefas ObterListaDeTarefasPorId(int id)
        {
            return listasDeTarefas.Find(l => l.Id == id);
        }

        public void ExcluirListaDeTarefas(int id)
        {
            var lista = ObterListaDeTarefasPorId(id);
            if (lista != null)
            {
                listasDeTarefas.Remove(lista);
                Console.WriteLine($"Lista de tarefas '{lista.Nome}' excluída.");
            }
        }
    }
}
