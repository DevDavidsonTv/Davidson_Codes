﻿using System;
using System.Collections.Generic;

namespace CPS___Taskyou___Entrega_Final
{
    internal class UsuarioDAO
    {
        private List<Usuario> usuarios;

        public UsuarioDAO()
        {
            usuarios = new List<Usuario>();
        }

        public void AdicionarUsuario(Usuario usuario)
        {
            usuario.Id = usuarios.Count + 1; // Simula a criação de um ID único
            usuarios.Add(usuario);
            Console.WriteLine($"Usuário '{usuario.Nome}' adicionado.");
        }

        public Usuario ObterUsuarioPorId(int id)
        {
            return usuarios.Find(u => u.Id == id);
        }

        public List<Usuario> ObterTodosUsuarios()
        {
            return usuarios;
        }
    }
}
