﻿using System;

namespace CPS___Taskyou___Entrega_Final
{
    internal class Contato
    {
        public int Id { get; set; }
        public int UsuarioId { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
    }
}
