﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace JogoDaVelha
{
        internal class Program
        {
            static string p1 = "1";
            static string p2 = "2";
            static string p3 = "3";
            static string p4 = "4";
            static string p5 = "5";
            static string p6 = "6";
            static string p7 = "7";
            static string p8 = "8";
            static string p9 = "9";

        static int Xvencedor()
        {
            int valor = 0;

            if ((Program.p1 == "X" && Program.p2 == "X" && Program.p3 == "X") || (Program.p4 == "X" && Program.p5 == "X" && Program.p6 == "X") || (Program.p7 == "X" && Program.p8 == "X" && Program.p9 == "X") || (Program.p1 == "X" && Program.p4 == "X" && Program.p7 == "X") || (Program.p2 == "X" && Program.p5 == "X" && Program.p8 == "X") || (Program.p3 == "X" && Program.p6 == "X" && Program.p9 == "X") || (Program.p1 == "X" && Program.p5 == "X" && Program.p9 == "X") || (Program.p3 == "X" && Program.p5 == "X" && Program.p7 == "X"))
            {
                valor = 1;
            }

            return valor;
        }

        static int Ovence()
        {
            int v = 0;

            if ((Program.p1 == "O" && Program.p2 == "O" && Program.p3 == "O") || (Program.p4 == "O" && Program.p5 == "O" && Program.p6 == "O") || (Program.p7 == "O" && Program.p8 == "O" && Program.p9 == "O") || (Program.p1 == "O" && Program.p4 == "O" && Program.p7 == "O") || (Program.p2 == "O" && Program.p5 == "O" && Program.p8 == "O") || (Program.p3 == "O" && Program.p6 == "O" && Program.p9 == "O") || (Program.p1 == "O" && Program.p5 == "O" && Program.p9 == "O") || (Program.p3 == "O" && Program.p5 == "O" && Program.p7 == "O"))
            {
                v = 1;
            }

            return v;
        }

        static void Main(string[] args)
            {
                int posicao;
                int posicaoX;
                int posicaoO;

                int vitoriaX;
                int vitoriaO;

                Console.ForegroundColor = ConsoleColor.Magenta;

                Console.WriteLine("Escreva o nome do primeiro jogador: ");
                string jg1 = Console.ReadLine();

                Console.ForegroundColor = ConsoleColor.Blue;

                Console.WriteLine("Escreva o nome do segundo jogador: ");
                string jg2 = Console.ReadLine();

                for (int i = 1; i <= 9; i++)
                {
                    vitoriaX = Program.Xvencedor();
                    vitoriaO = Program.Ovence();

                    if (vitoriaX == 0 && vitoriaO == 0)
                    {
                        if (i % 2 != 0)
                        {
                            Console.Clear();
                            Console.ForegroundColor = ConsoleColor.Magenta;

                            Console.WriteLine($"{jg1} (X) ,sua vez de jogar. Escolha uma casa: : ");
                            Program.Tabuleiro(Program.p1, Program.p2, Program.p3, Program.p4, Program.p5, Program.p6, Program.p7, Program.p8, Program.p9);
                            posicao = int.Parse(Console.ReadLine());
                            posicaoX = Program.PosicaoX(posicao);
                            Console.Clear();

                            switch (posicaoX)
                            {
                                case 1:
                                    Program.p1 = "X";
                                    break;
                                case 2:
                                    Program.p2 = "X";
                                    break;
                                case 3:
                                    Program.p3 = "X";
                                    break;
                                case 4:
                                    Program.p4 = "X";
                                    break;
                                case 5:
                                    Program.p5 = "X";
                                    break;
                                case 6:
                                    Program.p6 = "X";
                                    break;
                                case 7:
                                    Program.p7 = "X";
                                    break;
                                case 8:
                                    Program.p8 = "X";
                                    break;
                                case 9:
                                    Program.p9 = "X";
                                    break;
                            }
                        }
                        else
                        {
                            vitoriaO = Program.Ovence();
                            Console.Clear();
                            Console.WriteLine($"{jg2} (O) ,sua vez de jogar. Escolha uma casa: :");
                            Program.Tabuleiro(Program.p1, Program.p2, Program.p3, Program.p4, Program.p5, Program.p6, Program.p7, Program.p8, Program.p9);
                            posicao = int.Parse(Console.ReadLine());
                            posicaoO = Program.PosicaoO(posicao);

                            switch (posicaoO)
                            {
                                case 1:
                                    Program.p1 = "O";
                                    break;
                                case 2:
                                    Program.p2 = "O";
                                    break;
                                case 3:
                                    Program.p3 = "O";
                                    break;
                                case 4:
                                    Program.p4 = "O";
                                    break;
                                case 5:
                                    Program.p5 = "O";
                                    break;
                                case 6:
                                    Program.p6 = "O";
                                    break;
                                case 7:
                                    Program.p7 = "O";
                                    break;
                                case 8:
                                    Program.p8 = "O";
                                    break;
                                case 9:
                                    Program.p9 = "O";
                                    break;
                            }
                        }
                    }
                    if (vitoriaX == 1)
                    {
                        Console.Clear();

                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($"Parabéns {jg1}, você venceu o jogo!");
                    }
                    if (vitoriaO == 1)
                    {

                        Console.Clear();

                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($"Parabéns {jg2}, você venceu o jogo!");
                    }
                }

                Program.Velha();

                Console.ReadLine();
            }
        
            static void Tabuleiro(string p1, string p2, string p3, string p4, string p5, string p6, string p7, string p8, string p9)
            {

                /*Console.WriteLine(" " + p1 + "    |    " + p2 + "    |    " + p3 + " ");
                Console.WriteLine("-----------------------");
                Console.WriteLine(" " + p4 + "    |    " + p5 + "    |    " + p6 + " ");
                Console.WriteLine("-----------------------");
                Console.WriteLine(" " + p7 + "    |    " + p8 + "    |    " + p9 + " ");*/

                Console.ForegroundColor = ConsoleColor.Yellow;

                Console.WriteLine($"  {p1}  |  {p2}  |  {p3}  ");
                Console.WriteLine("------------------");
                Console.WriteLine($"  {p4}  |  {p5}  |  {p6}  ");
                Console.WriteLine("------------------");
                Console.WriteLine($"  {p7}  |  {p8}  |  {p9}  ");

            }
            static int PosicaoX(int casasX)
            {
                bool key = false;

                while (key == false)
                {
                if (casasX >= 1 && casasX <= 9)
                  {
                    switch (casasX)
                    {
                        case 1:
                            if (Program.p1 == "1")
                            {
                                Console.ForegroundColor = ConsoleColor.Blue;

                                casasX = 1;
                                key = true;
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;

                                Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel. ");
                                casasX = int.Parse(Console.ReadLine());
                            }
                            break;
                        case 2:
                            if (Program.p2 == "2")
                            {
                                Console.ForegroundColor = ConsoleColor.Blue;

                                casasX = 2;
                                key = true;
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;

                                Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel. ");
                                casasX = int.Parse(Console.ReadLine());
                            }
                            break;
                        case 3:
                            if (Program.p3 == "3")
                            {
                                Console.ForegroundColor = ConsoleColor.Blue;

                                casasX = 3;
                                key = true;
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;

                                Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel. ");
                                casasX = int.Parse(Console.ReadLine());
                            }
                            break;
                        case 4:
                            if (Program.p4 == "4")
                            {
                                Console.ForegroundColor = ConsoleColor.Blue;

                                casasX = 4;
                                key = true;
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;

                                Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel. ");
                                casasX = int.Parse(Console.ReadLine());
                            }
                            break;
                        case 5:
                            if (Program.p5 == "5")
                            {
                                Console.ForegroundColor = ConsoleColor.Blue;

                                casasX = 5;
                                key = true;
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;

                                Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                casasX = int.Parse(Console.ReadLine());
                            }
                            break;
                        case 6:
                            if (Program.p6 == "6")
                            {
                                Console.ForegroundColor = ConsoleColor.Blue;

                                casasX = 6;
                                key = true;
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;

                                Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                casasX = int.Parse(Console.ReadLine());
                            }
                            break;
                        case 7:
                            if (Program.p7 == "7")
                            {
                                Console.ForegroundColor = ConsoleColor.Blue;

                                casasX = 7;
                                key = true;
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;

                                Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                casasX = int.Parse(Console.ReadLine());
                            }
                            break;
                        case 8:
                            if (Program.p8 == "8")
                            {
                                Console.ForegroundColor = ConsoleColor.Blue;

                                casasX = 8;
                                key = true;
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;

                                Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                casasX = int.Parse(Console.ReadLine());
                            }
                            break;
                        case 9:
                            if (Program.p9 == "9")
                            {
                                Console.ForegroundColor = ConsoleColor.Blue;

                                casasX = 9;
                                key = true;
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;

                                Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                casasX = int.Parse(Console.ReadLine());
                            }
                            break;
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;

                    Console.WriteLine("Comando invalido, escolha novamente.");
                    casasX = int.Parse(Console.ReadLine());
                }
            }
               return casasX;
            }
       
        
           
            static void Velha()
            {
                if (Program.p1 != "1" && Program.p2 != "2" && Program.p3 != "3" && Program.p4 != "4" && Program.p5 != "5" && Program.p6 != "6" && Program.p7 != "7" && Program.p8 != "8" && Program.p9 != "9")
                {
                    Console.ForegroundColor = ConsoleColor.Red;

                    Console.WriteLine("Deu velha! Caso queira, tente novamente.");
                }
            }

           
            static int PosicaoO(int casasO)
            {
                bool key = false;

                while (key == false)
                {
                    if (casasO >= 1 && casasO <= 9)
                    {
                        switch (casasO)
                        {
                            case 1:
                                if (Program.p1 == "1")
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;

                                    casasO = 1;
                                    key = true;

                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                    casasO = int.Parse(Console.ReadLine());

                                }
                                break;
                            case 2:
                                if (Program.p2 == "2")
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;

                                    casasO = 2;
                                    key = true;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;

                                    Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                    casasO = int.Parse(Console.ReadLine());
                                }
                                break;
                            case 3:
                                if (Program.p3 == "3")
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;

                                    casasO = 3;
                                    key = true;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;

                                    Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                    casasO = int.Parse(Console.ReadLine());
                                }
                                break;
                            case 4:
                                if (Program.p4 == "4")
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;

                                    casasO = 4;
                                    key = true;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;

                                    Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                    casasO = int.Parse(Console.ReadLine());
                                }
                                break;
                            case 5:
                                if (Program.p5 == "5")
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;

                                    casasO = 5;
                                    key = true;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;

                                    Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                    casasO = int.Parse(Console.ReadLine());
                                }
                                break;
                            case 6:
                                if (Program.p6 == "6")
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;

                                    casasO = 6;
                                    key = true;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;

                                    Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                    casasO = int.Parse(Console.ReadLine());
                                }
                                break;
                            case 7:
                                if (Program.p7 == "7")
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;

                                    casasO = 7;
                                    key = true;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;

                                    Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                    casasO = int.Parse(Console.ReadLine());
                                }
                                break;
                            case 8:
                                if (Program.p8 == "8")
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;

                                    casasO = 8;
                                    key = true;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;

                                    Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                    casasO = int.Parse(Console.ReadLine());
                                }
                                break;
                            case 9:
                                if (Program.p9 == "9")
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;

                                    casasO = 9;
                                    key = true;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;

                                    Console.WriteLine("A posição ja esta sendo usada no tabuleiro. Escolha um numero que esteja disponivel.");
                                    casasO = int.Parse(Console.ReadLine());
                                }
                                break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Valor inválidom, escolha novamente.");
                        casasO = int.Parse(Console.ReadLine());
                    }
                }
                return casasO;
            }

        }
    
}
    

