﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp90
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int tamanhoMaxDaPilha = 100;
            int[] pilha = new int [tamanhoMaxDaPilha];
            int topo = -1;

            while (true)
            {
                Console.WriteLine("Digite um número inteiro ou operador (+, -, *, /).");
                string entrada = Console.ReadLine();

                if (int.TryParse(entrada, out int numero))
                {
                    //Verifica se a pilha esta cheia!
                    if (topo >= tamanhoMaxDaPilha - 1)
                    {
                        Console.WriteLine("Erro: Pilha cheia!");
                    }
                    else
                    {
                        topo++;
                        pilha[topo] = numero;
                        Console.WriteLine("Número empilhado com sucesso! ");
                    }
                }
                else if (entrada == "+" || entrada == "-" || entrada == "*" || entrada == "/")
                {
                    //Verifica se há pelo menos dois números na pilha 
                    if (topo < 1)
                    {
                        Console.WriteLine("Erro: Pilha não possui elementos suficientes para o operação!");
                    }
                    else
                    {
                        int segundoNumero = pilha[topo];
                        topo--;
                        int primeiroNumero = pilha[topo];
                        topo--;

                        int resultado = 0;
                        switch (entrada)
                        {
                            case "+":
                                resultado = primeiroNumero + segundoNumero;
                                break;

                            case "-":
                                resultado = primeiroNumero - segundoNumero;
                                break;

                            case "*":
                                resultado = primeiroNumero * segundoNumero;
                                break;

                            case "/":
                                if (segundoNumero != 0)
                                {
                                    resultado = primeiroNumero / segundoNumero;
                                }
                                else
                                {
                                    Console.WriteLine("Erro: Divisão por zero!");
                                    topo++; //Devolve o primeiro número para a pilha!
                                    pilha[topo] = primeiroNumero;
                                    continue;
                                }
                                break;
                        }
                        //Verifica se a pilha está cheia

                        if (topo >= tamanhoMaxDaPilha - 1)
                        {
                            Console.WriteLine("Erro: Pilha cheia!");
                            return;
                        }
                        topo++;
                        pilha[topo] = resultado;
                        Console.WriteLine($"Resultado: {resultado}  Empilhado com sucesso!");
                    }
                    
                }
                else
                {
                    Console.WriteLine("Erro: Operador inválido!");
                }
            }



        }
    }
}
