﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp93
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int codigoCliente = 1;
            int opcao;
            int aux;
            int y;
            Fila Pedido = new Fila(100);
            Fila Pagamento = new Fila(100);
            Fila Encomenda = new Fila(100);
            do
            {
                Console.WriteLine("1 - Inserção de cliente na fila de pedidos. ");
                Console.WriteLine("2 - Remoção de cliente da fila de pedidos. ");
                Console.WriteLine("3 - Remoção de cliente da fila de pagamentos. ");
                Console.WriteLine("4 - Remoção de cliente da fila de encomenda ");
                Console.WriteLine("5 - Sair. ");
                Console.WriteLine("Escolha uma opção: ");

                opcao = int.Parse(Console.ReadLine());

                switch (opcao)

                {
                    case 1:
                        Pedido.Enfileirar(codigoCliente);
                        Console.WriteLine($"Cliente {codigoCliente} entrou na fila. ");
                        codigoCliente++;
                        break;
                    case 2:
                        y = Pedido.Desenfileirar();
                        Console.WriteLine($"Cliente {y} saiu da fila de pedidos entrou na fila de pagamento");
                        Pagamento.Enfileirar(y);
                        break;
                    case 3:
                        aux = Pagamento.Desenfileirar();
                        Encomenda.Enfileirar(aux);
                        Console.WriteLine($"Cliente {aux} fez o pagamento. ");
                        break;
                    case 4:
                        int aux2 = Encomenda.Desenfileirar();
                        Console.WriteLine($"O cliente {aux2} pegou seu pedido e foi embora. ");
                        break;

                }

            }
            while (opcao != 5);



        }
    }
    
}
