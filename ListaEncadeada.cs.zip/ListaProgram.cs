﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pratica3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Lista l = new Lista();
            int opcao, c;
            string nome;
            do
            {
                Console.WriteLine("Menu:");
                Console.WriteLine("1) Inserir");
                Console.WriteLine("2) Pesquisar");
                Console.WriteLine("3) Imprimir Lista");
                Console.WriteLine("4) Sair");
                Console.Write("Escolha uma opção: ");
                opcao = Convert.ToInt32(Console.ReadLine());

                switch (opcao)
                {
                    case 1:
                        Console.Write("Digite um número: ");
                        c = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Digite um nome: ");
                        nome = Console.ReadLine();
                        l.Inserir(new NoLista(c, nome));
                        break;

                    case 2:
                        Console.Write("Digite um número a ser pesquisado: ");
                        c = Convert.ToInt32(Console.ReadLine());
                        NoLista n = l.Pesquisar(c);
                        if (n == null)
                            Console.WriteLine("Valor não encontrado!");
                        else
                        {
                            Console.WriteLine($"Achou: Chave: {n.chave}, Nome: {n.nome}");
                            Console.Write("Deseja remover este nó? (S/N): ");
                            string resposta = Console.ReadLine();
                            if (resposta.ToUpper() == "S")
                            {
                                if (l.Remover(n.chave))
                                    Console.WriteLine("Nó removido com sucesso.");
                                else
                                    Console.WriteLine("Erro ao remover o nó.");
                            }
                        }
                        break;

                    case 3:
                        l.Imprimir();
                        break;

                    case 4:
                        Console.WriteLine("Saindo do programa...");
                        break;

                    default:
                        Console.WriteLine("Opção inválida!");
                        break;
                }
            } while (opcao != 4);
        }
    }
}

