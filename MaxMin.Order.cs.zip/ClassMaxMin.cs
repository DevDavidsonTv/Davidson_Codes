﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pratica4
{
    internal class MaxMin
    {
        private static int contadorMaxMin1;
        private static int contadorMaxMin2;
        private static int contadorMaxMin3;

        public static int ContadorMaxMin1 { get { return contadorMaxMin1; } }
        public static int ContadorMaxMin2 { get { return contadorMaxMin2; } }
        public static int ContadorMaxMin3 { get { return contadorMaxMin3; } }

        public MaxMin()
        {
            ResetarContadores();
        }

        public static void ResetarContadores()
        {
            contadorMaxMin1 = 0;
            contadorMaxMin2 = 0;
            contadorMaxMin3 = 0;
        }

        public void MaxMin1(int[] vet, out int ma, out int me)
        {
            ma = me = vet[0];
            for (int i = 1; i < vet.Length; i++)
            {
                if (vet[i] < me)
                {
                    me = vet[i];
                    contadorMaxMin1++;
                }
                if (vet[i] > ma)
                {
                    ma = vet[i];
                    contadorMaxMin1++;
                }
            }
        }

        public void MaxMin2(int[] vet, out int ma, out int me)
        {
            ma = me = vet[0];
            for (int i = 1; i < vet.Length; i++)
            {
                if (vet[i] < me)
                {
                    me = vet[i];
                    contadorMaxMin2++;
                }
                else if (vet[i] > ma)
                {
                    ma = vet[i];
                    contadorMaxMin2++;
                }
            }
        }

        public void MaxMin3(int[] vet, out int ma, out int me)
        {
            if (vet[0] < vet[1])
            {
                me = vet[0];
                ma = vet[1];
            }
            else
            {
                me = vet[1];
                ma = vet[0];
            }

            for (int i = 2; i < vet.Length; i += 2)
            {
                if (vet[i] < vet[i + 1])
                {
                    if (vet[i] < me)
                    {
                        me = vet[i];
                        contadorMaxMin3++;
                    }
                    if (vet[i + 1] > ma)
                    {
                        ma = vet[i + 1];
                        contadorMaxMin3++;
                    }
                }
                else
                {
                    if (vet[i + 1] < me)
                    {
                        me = vet[i + 1];
                        contadorMaxMin3++;
                    }
                    if (vet[i] > ma)
                    {
                        ma = vet[i];
                        contadorMaxMin3++;
                    }
                }
            }
        }
    }
}
