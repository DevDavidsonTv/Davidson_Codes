﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pratica4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MaxMin maxMin = new MaxMin();
            Random rand = new Random();
            int[] vetorCrescente = new int[1000];
            int[] vetorDecrescente = new int[1000];
            int[] vetorAleatorio = new int[1000];

            PreencherVetorCrescente(vetorCrescente);
            PreencherVetorDecrescente(vetorDecrescente);
            PreencherVetorAleatorio(vetorAleatorio);

            // Executar os métodos e exibir resultados
            ExecutarMaxMin(maxMin, vetorCrescente, "Ordem Crescente");
            ExecutarMaxMin(maxMin, vetorDecrescente, "Ordem Decrescente");
            ExecutarMaxMin(maxMin, vetorAleatorio, "Aleatório");

            Console.ReadLine();
        }
        static void PreencherVetorCrescente(int[] vetor)
        {
            for (int i = 0; i < vetor.Length; i++)
            {
                vetor[i] = i + 1;
            }
        }

        static void PreencherVetorDecrescente(int[] vetor)
        {
            for (int i = 0; i < vetor.Length; i++)
            {
                vetor[i] = vetor.Length - i;
            }
        }

        static void PreencherVetorAleatorio(int[] vetor)
        {
            Random random = new Random();
            for (int i = 0; i < vetor.Length; i++)
            {
                vetor[i] = random.Next(1, 1001); // Números aleatórios de 1 a 1000
            }
        }

        static void ExecutarMaxMin(MaxMin maxMin, int[] vetor, string descricao)
        {
            int ma, me;

            // Método MaxMin1
            maxMin.MaxMin1(vetor, out ma, out me);
            Console.WriteLine($"MaxMin1 - {descricao}: Máximo = {ma}, Mínimo = {me}, Comparações = {MaxMin.ContadorMaxMin1}");
            ResetarContadores(maxMin);

            // Método MaxMin2
            maxMin.MaxMin2(vetor, out ma, out me);
            Console.WriteLine($"MaxMin2 - {descricao}: Máximo = {ma}, Mínimo = {me}, Comparações = {MaxMin.ContadorMaxMin2}");
            ResetarContadores(maxMin);

            // Método MaxMin3
            maxMin.MaxMin3(vetor, out ma, out me);
            Console.WriteLine($"MaxMin3 - {descricao}: Máximo = {ma}, Mínimo = {me}, Comparações = {MaxMin.ContadorMaxMin3}");
            ResetarContadores(maxMin);

            Console.WriteLine();
        }

        static void ResetarContadores(MaxMin maxMin)
        {
            // Resetar contadores para a próxima execução
            MaxMin.ResetarContadores();
        }
    }
    
}
